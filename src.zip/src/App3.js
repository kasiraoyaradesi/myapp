import React from 'react'

export default function App3(props) {
    console.log(props.name[1])
  return (
    <div>App3</div>
  )
}


// For array


// props are transfer the data from one component to another component i.e parent(App.js) to child (componnents)