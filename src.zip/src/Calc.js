
function Calc(props) {

    let x = props.a
    let y = props.b
    let z = props.a + props.b
    return (<div>  result is = {z} </div>
      
    )
  }
  
  export default Calc