import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import App1 from './App1';
// import Calc from './Calc';
// import Result from './Result';
// import App2 from './App2'
// import App3 from './App3'

// import App4 from './App4'

// import App5 from './App5'

// import App6 from './App6'

// import Product from './Product'

// import Coffe from './Coffe'

// import App8 from './App8'

// import App9 from './App9'

// import App10 from './App10'

import App24 from './App24'

// import App13a from './App13a'


// import Login1 from './Login1'
// import App14 from "./App14";

// import App15 from "./App15";

// import App16 from "./App16";

// import App17 from "./App17";








const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
     {/* <App1 name= "Jhon" age = {34} /> */}

   {/* <Calc  a= {2}  b = {4} /> */}

   {/* < Result marks = {20}/> */}
   {/* {/ <App2 user ="" />   if use name then coming name only otherwise box} */}


  {/* <App3 name = {["jhon","cathy"]}/> */}

  {/* <App5 student = {{name:"jhon", age:28}}/> */}


  {/* <App5/> */}
  {/* <App6/> */}

  {/* <Coffe/> */}

  {/* <App8 /> */}

  {/* <App9 /> */}


  {/* <App10 /> */}

  {/* <Login1/> */}

  {/* <App13a/> */}

  {/* <App14/> */}

  {/* <App15/> */}

  {/* <App16/> */}

  {/* <App17/> */}

  <App24 />


  </React.StrictMode>
);

