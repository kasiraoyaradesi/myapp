
 function Box1() {
  return 
    <div>Box</div>
  
}
function Box2() {
  return 
    <div>Box</div>
  
}


export default Box1,Box2