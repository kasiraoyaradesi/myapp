import './App.css';

import Header from './Header';
import Box1 from './Box1';
import Box2 from './Box2';



function App() {
  return (
    <div>
           <div><h1><Header/> </h1> </div>  
  
      <div>
           <div><Box1/></div>
            <div><Box2/> </div>
       </div>

       <div> </div>


      </div>
     
  );
}


