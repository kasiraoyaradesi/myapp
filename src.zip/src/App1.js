
 function App1(props) {
  return (<div> Hello  {props.name}.Are you
  {props.age}?</div>
    
  )
}

export default App1