// import React from 'react'

// export default function App8(props) {
     
//   return (
   
//     <div style={{backgroundColor:'red'}}>
//         Hello {props.name} . you are {props.age}
//         </div>
//   )
// }

// App8.defaultProps = {name: "cathy",age:20}