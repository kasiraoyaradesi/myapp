import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import App1 from './App1';
// import Calc from './Calc';
// import Result from './Result';
// import App2 from './App2'
// import App3 from './App3'

// import App4 from './App4'

// import App5 from './App5'

// import App6 from './App6'

import Product from './Product'



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
     {/* <App1 name= "Jhon" age = {34} /> */}

   {/* <Calc  a= {2}  b = {4} /> */}

   {/* < Result marks = {20}/> */}
   {/* {/ <App2 user ="" />   if use name then coming name only otherwise box} */}


  {/* <App3 name = {["jhon","cathy"]}/> */}

  {/* <App5 student = {{name:"jhon", age:28}}/> */}


  {/* <App5/> */}
  {/* <App6/> */}

  <Product/>



  </React.StrictMode>
);

