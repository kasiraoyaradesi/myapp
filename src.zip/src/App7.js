import React from 'react';
 import './App.css';
import App6 from './App6';


function App() {
  return (
  <div className='App'>
    <Header />
    <hr></hr>
    <App6 />
    <hr></hr>
    <Footer />  
                                      
    </div>
  );
}

export default App;