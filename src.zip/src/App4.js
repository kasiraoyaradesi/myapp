// object

import React from 'react'

export default function App4(props) {
    console.log(props.student.name)
  return (
    <div>App4</div>
  )
}
