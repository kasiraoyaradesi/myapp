let Product = [
      
         {  id:1,
             name: "cappuccino",
             price: 20,
             image: "images-1.png",

            }
          
        
    ]


    export default Product;