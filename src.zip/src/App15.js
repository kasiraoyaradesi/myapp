import React from 'react'
import App15child from './App15child'
export default function App15() {
  return (
    <div>
        <App15child>
            <h1>Hello World</h1>
        </App15child>
    </div>
  )
}