import React from 'react'

export default function Fail(props) {
  return (
    <div>Fail</div>
  )
}
