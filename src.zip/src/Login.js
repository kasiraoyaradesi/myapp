import React from 'react';




export default function Login() {
  return (
    <div>
        <h1>Login Form</h1>
    <div> <input type="text" palceholder="Enter username"></input> </div>
    <div> <input type="text" palceholder="Enter password"></input> </div>
    <div> <input type="button" value = "Submit" ></input> </div>
    </div>


  )
}
