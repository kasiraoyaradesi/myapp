import React from 'react'
import { FaHome, FaBookmark } from "react-icons/fa";
export default function App10() {
  return (
    <div>
        <p><FaHome/>Home</p>
        <p><FaBookmark />Feeds</p>
        <p>Post</p>
        <p>Album</p>
    </div>
  )
}