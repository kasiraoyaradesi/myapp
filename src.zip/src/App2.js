import React from 'react';
// import Login from './Login';
// import Home from './Home';

export default function App2(props) {

    // return props.user === "" && 

    // ( <div>
    //     <h1>Login Form</h1>
    //     <div> <input type="text" palceholder="Enter Username"></input> </div>
    //    <div> <input type="text" palce holder="Enter password"></input> </div>
    //    <div> <input type="button" value = "Submit" ></input> </div>
    // </div>
    // ) 
    //           :
    //               ( <div>Hello  {props.user}</div> )   ;
    

    // ( <div>
    //     <h1>Login Form</h1>
    //     <div> <input type="text" palceholder="Enter Username"></input> </div>
    //    <div> <input type="text" palce holder="Enter password"></input> </div>
    //    <div> <input type="button" value = "Submit" ></input> </div>
    // </div>) 
    //           :
    //               ( <div>Hello  {props.user}</div> ) )  ;


    // return (props.user === ""? <Login/> : <Home username={props.user} /> ); one procee is up home and logins are in comment

//     if (props.user===""){
//         return<Login/>;
//     }
//    else {
//     return <Home username={props.user}/>;
//    }


}
