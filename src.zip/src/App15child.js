import React from 'react'
export default function App15child(props) {
  return (
    <div style={{backgroundColor:'red'}}>
        {props.children}
    </div>
  )
}