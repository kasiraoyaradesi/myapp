import React from 'react'


export default function Home(props) {
  return (
    <div>Hello user {props.username}</div>
  )
}
