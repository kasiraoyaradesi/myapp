import React from 'react'

export default function App() {

    let Product = [
      
        {  id:1,
            name: "cappuccino",
            price: 20,
            image: "images-1.png",

           }
         
       
   ]
    
    return (

        <div>
        {
            Product.map((item)=>{
                return (
                    <li >
                       <img key={item.id} src={item.image} alt=""/>
                    </li>
                )
            })
        }

        </div>
      );
      } 
    
